defmodule Irankerg.LayoutViewTest do
  use Irankerg.ConnCase, async: true
end
