defmodule Irankerg.PageViewTest do
  use Irankerg.ConnCase, async: true
end
