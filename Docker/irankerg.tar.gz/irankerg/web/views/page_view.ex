defmodule Irankerg.PageView do
  use Irankerg.Web, :view
end
