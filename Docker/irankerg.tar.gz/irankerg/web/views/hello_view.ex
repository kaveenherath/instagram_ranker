defmodule Irankerg.HelloView do
  use Irankerg.Web, :view
end
