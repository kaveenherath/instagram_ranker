defmodule Irankerg.LayoutView do
  use Irankerg.Web, :view
end
