mix deps.get 
npm install 

